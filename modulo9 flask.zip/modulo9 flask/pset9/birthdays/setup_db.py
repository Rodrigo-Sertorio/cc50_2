import sqlite3

# Conectar ou criar o banco de dados
conn = sqlite3.connect('birthdays.db')
cursor = conn.cursor()

# Criar a tabela de aniversários
cursor.execute('''
CREATE TABLE birthdays (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    month INTEGER NOT NULL,
    day INTEGER NOT NULL
)
''')

# Salvar e fechar a conexão
conn.commit()
conn.close()

print("Banco de dados e tabela criados com sucesso.")
