import sqlite3
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    conn = sqlite3.connect("birthdays.db")
    cursor = conn.cursor()

    if request.method == "POST":
        # Inserir um novo aniversário
        name = request.form.get("name")
        month = request.form.get("month")
        day = request.form.get("day")

        cursor.execute("INSERT INTO birthdays (name, month, day) VALUES (?, ?, ?)", (name, month, day))
        conn.commit()

    # Obter todos os aniversários
    cursor.execute("SELECT * FROM birthdays")
    birthdays = cursor.fetchall()

    conn.close()

    return render_template("index.html", birthdays=birthdays)
