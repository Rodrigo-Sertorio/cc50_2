// Pergunta de múltipla escolha
document.querySelectorAll('.answer').forEach(button => {
    button.addEventListener('click', function() {
        const correct = this.dataset.correct === "true";
        const feedback = document.querySelector('#feedback');

        if (correct) {
            this.style.backgroundColor = 'green';
            feedback.textContent = "Correto!";
        } else {
            this.style.backgroundColor = 'red';
            feedback.textContent = "Incorreto!";
        }
    });
});

// Pergunta de resposta livre
document.querySelector('#submit-text').addEventListener('click', function() {
    const userAnswer = document.querySelector('#text-answer').value.trim().toLowerCase();
    const feedback = document.querySelector('#text-feedback');
    const correctAnswer = "h2o";

    if (userAnswer === correctAnswer) {
        document.querySelector('#text-answer').style.backgroundColor = 'green';
        feedback.textContent = "Correto!";
    } else {
        document.querySelector('#text-answer').style.backgroundColor = 'red';
        feedback.textContent = "Incorreto!";
    }
});
