function mostrarMensagem() {
    alert("Você clicou no botão! Vamos aprender mais sobre programação juntos!");
}
