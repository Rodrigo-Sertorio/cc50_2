from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()  # Instancia do SQLAlchemy

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task_name = db.Column(db.String(120), nullable=False)

    def __repr__(self):
        return f'<Task {self.task_name}>'
