import pytest
from app import create_app
from models import db, Task

@pytest.fixture
def app():
    app = create_app()  # Cria a aplicação Flask para os testes

    # Configuração para usar um banco de dados SQLite em memória durante os testes
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'

    with app.app_context():
        db.create_all()  # Cria as tabelas no banco de dados
        yield app
        db.drop_all()  # Remove as tabelas após os testes

@pytest.fixture
def client(app):
    return app.test_client()

def test_add_task(client):
    # Envia um POST para adicionar a tarefa
    response = client.post('/add', data={'task_name': 'New Task'})

    # Verifica se o status é 302 (Redirecionamento)
    assert response.status_code == 302

    # Verifica se o redirecionamento foi para a página inicial
    assert response.location == 'http://localhost/'
