from flask import Flask, render_template, request, redirect, url_for

# Certifique-se de que a função create_app() seja chamada antes
def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')  # Carrega a configuração do arquivo config.py

    # Importa o db e os modelos dentro da função para evitar a importação circular
    from models import db, Task
    db.init_app(app)  # Inicializa o banco de dados

    # Cria as tabelas no banco de dados, caso não existam
    with app.app_context():
        db.create_all()

    @app.route('/')
    def index():
        tasks = Task.query.all()  # Recupera todas as tarefas
        return render_template('index.html', tasks=tasks)  # Passa as tarefas para o template

    @app.route('/add', methods=['POST'])
    def add_task():
        task_name = request.form['task_name']  # Pega o nome da tarefa do formulário
        task = Task(task_name=task_name)  # Cria uma nova tarefa
        db.session.add(task)  # Adiciona a tarefa à sessão do banco de dados
        db.session.commit()  # Confirma a transação
        return redirect(url_for('index'))  # Redireciona para a página inicial

    return app
